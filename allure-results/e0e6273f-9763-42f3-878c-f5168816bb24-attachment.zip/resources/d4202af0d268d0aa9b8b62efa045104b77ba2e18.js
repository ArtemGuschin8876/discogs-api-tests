/*!
 * IMPORTANT NOTE:
 * 
 *   This file is licensed only for the use of Apple developers in providing MusicKit Web Services,
 *   and is subject to the Apple Media Services Terms and Conditions and the Apple Developer Program
 *   License Agreement. You may not copy, modify, re-host, or create derivative works of this file or the
 *   accompanying Documentation, or any part thereof, including any updates, without Apple's written consent.
 * 
 *   ACKNOWLEDGEMENTS:
 *   https://js-cdn.music.apple.com/musickit/v1/acknowledgements.txt
 */
import{r as t,a as i,h as n,c as s,H as o}from"./p-333be98f.js";const a=new Map,e=class{constructor(i){t(this,i),this.iconContent=void 0,this.name=void 0}async nameChanged(t,i){t!==i&&await this.loadAsset()}async componentWillLoad(){await this.loadAsset()}async loadAsset(){const{name:t}=this;if(!(t=>(null==t?void 0:t.length)>0&&/^[a-zA-Z0-9-.]+$/.test(t))(t))return this.iconContent="",void console.warn(`"${t}" is not a valid icon name.`);if(a.has(t))this.iconContent=a.get(t);else try{const n=await fetch(i(`assets/icons/${t}.svg`));if(!n.ok)throw this.iconContent="",new Error("Icon not found");this.iconContent=await n.text(),a.set(t,this.iconContent)}catch(n){console.warn("Cannot load icon",this.name),this.iconContent=""}}render(){return n(o,{class:"icon",role:"presentation","aria-hidden":"true",innerHTML:this.iconContent})}get el(){return s(this)}static get watchers(){return{name:["nameChanged"]}}};e.style=".icon{display:block}.icon svg{width:inherit;height:inherit;display:block;color:currentColor;pointer-events:none}.icon svg *{fill:currentColor}";export{e as amp_icon}